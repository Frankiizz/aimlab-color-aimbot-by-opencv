import time
import pydirectinput
import cv2
import keyboard
import win32con, win32api, win32gui
import numpy as np
import mss

# move and click function.
def click(x, y):
	currentx, currenty = pydirectinput.position()
	# On 3D game, you can only use relative distance.
	# The line down calculates the distance between your aim point and object you want to shoot.
	pydirectinput.moveRel(x - currentx, y - currenty, relative=True)
	# click part
	win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
	win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)
	# if you delet this time.sleep, it may click twice on the same point
	time.sleep(0.001)

# The ragion u want to grab
monitor = {'top':0 , 'left': 0, 'width':1280 , 'height':750}

# Mask for IMAGE
with mss.mss() as sct:
	# Press q to stop
	while keyboard.is_pressed('q') == False:

		img_or = sct.grab((monitor))
		# Convert to np format so that cv2 can read it.
		img = np.array(img_or)
		hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)


		low_red = np.array([178, 180, 180])
		up_red = np.array([180, 255, 255])

		mask = cv2.inRange(hsv_img, low_red, up_red)

		kernel = np.ones((5, 5), np.uint8)
		mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
		mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

		contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
		# prevent too many rectangles on the same object.
		for contour in contours:
			x, y, w, h = cv2.boundingRect(contour)
			img = cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 1)
			cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 1)
			x_loc, y_loc = int(x + 0.5 * w), int(y + 0.5 * h)

			click(x_loc, y_loc)
			break
		# ***I cover this part for faster detection, if you want to check the feedback of detection, just
		# remove all hash key
		# These 4 line use to resize windows of feedback smaller
		#cv2.namedWindow('targehsv', 0)
		#cv2.namedWindow('pic', 0)
		#cv2.resizeWindow('targehsv', 640, 360)
		#cv2.resizeWindow('pic', 640, 360)

		#cv2.imshow('targehsv', mask)
		#cv2.imshow('pic', img)
		#cv2.imshow('res', res)
		#cv2.waitKey(1)



