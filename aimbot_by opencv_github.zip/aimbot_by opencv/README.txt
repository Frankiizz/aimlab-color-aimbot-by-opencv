1. On game matlab, choose csgo as your game mode and select a windowsize and find its optional mouse sensitivity.
Sensitivity effect a lot. 
2. my suggestion is use print(pydirectinput.position) to test if your mouse move the same distance
on game and your deskpot, balance the sensitivity till they matched.
3. if you want to check contours and hsv image, please remove hash key before im.show and im.xxx...
I will mark on the main.py
4. There are hsv values I tested on color_hsv.txt
5.if you want to find other color, please check HSV.png，the x_axis is H and y_axis is S and for the
last letter V or B(sometimes, people use HSB, but there are literally the same.XD) represent Bright,
you don't need find it value on this table, just try(it is always around 255)
6. Use squeeze rule to find the perfect value for HSV/B
good luck.