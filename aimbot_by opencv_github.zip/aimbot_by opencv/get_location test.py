import win32gui



def get_mouse_location():
	mouse_x, mouse_y = win32gui.GetCursorPos()
	print(mouse_x, mouse_y)

while True:
	get_mouse_location()