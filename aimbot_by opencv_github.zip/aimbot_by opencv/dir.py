import pydirectinput

pydirectinput.moveRel(X)